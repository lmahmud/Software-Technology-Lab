package dbadapter;

/**
 * Data representation of a Donation
 * 
 * @author kt
 *
 */
public class Donation {
  // TODO
}
