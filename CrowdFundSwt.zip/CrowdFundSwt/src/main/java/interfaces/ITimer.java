package interfaces;

import javax.servlet.annotation.WebListener;

/**
 * Interface for the timer
 */
public interface ITimer {
    void checkEndDate();
}
